package FinalProj.utils.events;

public interface Event<T> {
    T getState();
}

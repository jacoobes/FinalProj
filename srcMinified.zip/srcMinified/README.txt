

  ________ ____ ___.___.____  ___________
 /  _____/|    |   \   |    | \__    ___/
/   \  ___|    |   /   |    |   |    |
\    \_\  \    |  /|   |    |___|    |
 \______  /______/ |___|_______ \____|
        \/                     \/



A game made with the BasicGraphics library.

Features
    - 19 scenes
    - Rudimentary observer Pattern
    - A story
    - 3 endings
    - sound
    - sprite animation
    - Multiple Paths

Some important classes to make this game work

ResourceLoader
    - manages
        - current profile
        - backup profile
        - subscribers
        - pictures
        - sounds
        - font loading
        - text choices

Profiles are stored in src/FinalProj/resources/database
    - stores 3 possible users
    - uses yaml persistence ( via snake-yaml )
    - stores important data

class TextEmitter
    - is a Publisher<Boolean>

Each scene is a subscriber, inheriting from SceneAlpha.

SceneAlpha is just an abstract class that has shared logic among ALL Scenes.

The textEmitter emits an event to its subscribers and that event is sent to the update method.
all scenes implement Subs<Boolean> and have an update method to receive the text emitter finished event.

This allows a smooth pub-sub event based text game with smooth transitions to the next scene.

The only issue I had trouble with was making my sprite have a transparent background.

!!!!!!!!
To professor Brandt, I have given you a minifed version, removing sound effects to keep it under to 10mb limit.
If you ever want to try it with sound,

Clone from the repo : https://github.com/jacoobes/FinalProj.git

